//
//  methinksiOS.h
//  methinksiOS
//
//  Created by Philip Yun on 7/23/20.
//  Copyright © 2020 Philip Yun. All rights reserved.
//

#ifndef MTKAppInsight_h
#define MTKAppInsight_h
#import "MTKSDK.h"
//#import <methinksiOS/MTKSDK.h>
#endif /* methinksiOS_h */
